package com.cg.scheduleplanforteacher.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;



import com.cg.scheduleplanforteacher.bean.Teacher;

@Repository
@Transactional
public class IDAOImpl implements IDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Teacher insertDetails(Teacher plan) {
		System.out.println(plan.getComments());
		entityManager.persist(plan);
		entityManager.flush();
		return plan;
	}


}
