package com.cg.scheduleplanforteacher.dao;

import com.cg.scheduleplanforteacher.bean.Teacher;

public interface IDao {
public Teacher insertDetails(Teacher plan);
}
