package com.cg.scheduleplanforteacher.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.scheduleplanforteacher.bean.Teacher;
import com.cg.scheduleplanforteachers.service.*;
@Controller
public class TeacherPlanController {
	
	@Autowired
	public Iservice service;
	
	@RequestMapping("index")
	public ModelAndView getHomePage(){
		ModelAndView mv=new ModelAndView();
		mv.setViewName("HomePage");
		return mv;
		
	}
	@RequestMapping("setPlan")
	public ModelAndView insertPlan(Model m){
		ModelAndView mv=new ModelAndView();
		Teacher t=new Teacher();
		mv.addObject("plan",t);
		ArrayList<String> list=new ArrayList<>();
		list.add("MATHS");
		list.add("HISTORY");
		list.add("BIOLOGY");
		list.add("PHYSICS");
		list.add("CHEMISTRY");
		mv.addObject("seltperiod", list);
		mv.setViewName("details");
		return mv;
	}
	@RequestMapping(value="/view",method=RequestMethod.POST)
	public ModelAndView validate(@ModelAttribute("plan") @Valid Teacher teach,BindingResult br,Model m){
		ModelAndView mv=new ModelAndView();
		if(br.hasErrors()){
			mv.setViewName("details");
		}
		else
		{
			Teacher t=new Teacher();
			t=service.insertDetails(teach);
			mv.addObject("id", t.getFacId());
			mv.setViewName("success");
		}
		return mv;
	}
	@RequestMapping(value="/getPlan")
	public ModelAndView viewById() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("idSearch");
		return mv;
	}
}
