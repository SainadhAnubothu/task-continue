package com.cg.scheduleplanforteachers.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.scheduleplanforteacher.bean.Teacher;
import com.cg.scheduleplanforteacher.dao.IDao;

@Service
public class IServiceImpl implements Iservice{

	@Autowired
	IDao dao;
	@Override
	public Teacher insertDetails(Teacher plan) {
		return dao.insertDetails(plan);
	}
	
	
}

